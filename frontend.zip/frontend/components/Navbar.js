import NotificationBell from "./NotificationBell";

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center bg-gray-800 text-white px-6 py-3">
      <h1 className="text-xl font-bold">Task Manager</h1>
      <NotificationBell />
    </nav>
  );
}
