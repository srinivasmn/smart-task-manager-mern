import { useQuery, gql, useMutation } from "@apollo/client";
import { useEffect } from "react";
import Navbar from "../components/Navbar";
import NotificationBell from "../components/NotificationBell";
import SyncBanner from "../components/SyncBanner";

const TASKS = gql`query { tasks { id title description status assignee { name } } }`;

export default function Dashboard() {
  const { data, loading } = useQuery(TASKS);

  return (
    <div>
      <Navbar />
      <SyncBanner />
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">Tasks</h2>
        {loading ? <p>Loading...</p> : (
          <ul>
            {data.tasks.map((task) => (
              <li key={task.id} className="border p-4 mb-2 rounded">
                <h3 className="font-semibold">{task.title}</h3>
                <p>{task.description}</p>
                <span className="text-sm text-gray-600">Assigned to: {task.assignee?.name || "Unassigned"}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
