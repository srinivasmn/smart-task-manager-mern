import { ApolloClient, InMemoryCache, createHttpLink } from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import { persistCache } from "apollo3-cache-persist";

const httpLink = createHttpLink({ uri: process.env.NEXT_PUBLIC_API_URL });

const authLink = setContext((_, { headers }) => {
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : "";
  return { headers: { ...headers, authorization: token ? `Bearer ${token}` : "" } };
});

const cache = new InMemoryCache();

if (typeof window !== "undefined") {
  persistCache({ cache, storage: window.localStorage });
}

const client = new ApolloClient({ link: authLink.concat(httpLink), cache });
export default client;
